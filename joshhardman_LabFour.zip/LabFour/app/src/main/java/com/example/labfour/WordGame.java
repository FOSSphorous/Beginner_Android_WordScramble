package com.example.labfour;

public class WordGame {

    public com.example.labthree.WordList unscrambledList = new com.example.labthree.WordList();

    int arrLength = unscrambledList.unscrambledWordList.length;
    public String plaintextWord = "";
    public String scrambledWord = "";
    public int triesLeft;

}
